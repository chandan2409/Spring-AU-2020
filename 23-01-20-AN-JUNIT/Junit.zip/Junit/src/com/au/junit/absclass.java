package com.au.junit;

import junit.framework.TestCase;

public class absclass extends  TestCase {
	protected int value1,value2;
	
public void testAdd()
{
	int result=6;
	assertTrue(result==6);
}
}

package com.au.junit;

public class Employee {
private String name;
private double monthlysalary;
private int age;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public double getMonthlysalary() {
	return monthlysalary;
}
public void setMonthlysalary(double monthlysalary) {
	this.monthlysalary = monthlysalary;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}

}
